var express = require('express');
var router = express.Router();
var con = require('./connection.js');
//MSSQL
var sqlclient = require("mssql");

router.get('/notouch', function (req, res, next) {

    var conn=con.connection(req.query.selectDate ,req.query.shift)
    
    var running = "Activity Area Running - Point";
    var query ="select max(lSeconds)as maxlSeconds,avg(lSeconds)as avglSeconds,min(lSeconds)as minlSeconds,(count(sCategory)-1) as count from MINT_MachineState where (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "') and (WorkcellDesc = '" + req.query.line + "') and (sCategory='" + running + "')";
 
     sqlclient.connect(conn, function (connectionerr) {

         if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

router.get('/StatusNotouchtab', function (req, res, next) {

    var conn=con.connection(req.query.selectDate ,req.query.shift)
    
    var query ="select tStart, tEnd, sCategory, sEventDesc ,CAST((tEnd-tStart) as time(0)) as machinetime  from MINT_MachineState where (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "') and (WorkcellDesc = '" + req.query.line + "') order by lOEEEventId asc";

     sqlclient.connect(conn, function (connectionerr) {

         if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

router.get('/lossdesc', function (req, res, next) {

    var conn=con.connection(req.query.selectDate ,req.query.shift)
    
    var query ="select lSeconds, sCategory, SmartTag as sEventDesc  from MINT_MachineState where (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "') and (WorkcellDesc = '" + req.query.line + "') and(tStart='" + req.query.tstart + "') and(tEnd='" + req.query.tEnd + "')";

     sqlclient.connect(conn, function (connectionerr) {

         if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

module.exports = router;

