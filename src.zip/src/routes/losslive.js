var express = require('express');
var router = express.Router();
var DBconfig = require('../../config.json');
var conn = DBconfig.connectionString;
//MSSQL
var sqlclient = require("mssql");

router.get('/getWorkcellname', function (req, res, next) {

    var query = "SELECT [sActivityAreaName] FROM [FDMActivityArea] WHERE (([lFDMActivityAreaLevelId] = 0) AND ([sActivityAreaName] <> 'Historian Demo Workcell') AND ([sActivityAreaName] <> 'TEST')) ORDER BY [lFDMActivityAreaId] asc";

    sqlclient.connect(conn, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});


router.get('/getEventData', function (req, res, next) {

    var query = "select lMINTEventId, tDate, sShift, WorkcellDesc, (CONVERT(varchar(50),lSeconds)) as lSeconds, " +
        "tStart, tEnd, LossDesc from MINT_HUL_Events where ((tDate = '" + req.query.selectDate + "') and " +
        "(sShift = '" + req.query.shift + "') and (WorkcellDesc = '" + req.query.machine + "') and (lSeconds > '5') " +
        " and LossDesc !='Speed Loss' and LossDesc!='Quality Loss') order by tStart desc";

    sqlclient.connect(conn, function (connectionerr) {

        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

router.get('/GetMMPCategory', function (req, res, next) {

    var query = "select distinct MMPLossCodeDesc, MMPLossCodeID from MINT_HUL_MMPLossCode "+
    " where MMPCodeID="+req.query.CategoryCode+" order by MMPLossCodeID asc";

    sqlclient.connect(conn, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

//GetCategoryMachines, GetMachineLoss
router.get('/getMainCategory', function (req, res, next) {

    var query = "select * from MINT_HUL_MMPCode";

    sqlclient.connect(conn, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

router.get('/GetMachineLoss', function (req, res, next) {

    var query = "select SmartTag as LossDesc,LossCode from Mint_vSmartTags where CategoryCode='" + req.query.MMPCategory + "'";

    sqlclient.connect(conn, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

//updateloss
router.post('/updateloss', function (req, res, next) {

    var query = "update OEEEvent set dEnd = '" + req.body.mLossCode + "', sEndVal = '" + req.body.LossSelect + "' where (lOEEEventId = '" + req.body.eventid + "')";
    // var query = "update MINT_tHUL_Events set sEventDesc = '" + req.body.mLossCode + "', LossDesc = '" + req.body.LossSelect + "' where ([lMINTEventId] = '"+'D' + req.body.eventid + "')";

    sqlclient.connect(conn, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            if (result != 'undefined') {
                res.send(result);
            }
        });
    });
});

// router.get('/GetRootcause', function (req, res, next) {

//     var query = "select distinct MMPLossCodeDesc, CategoryCode from Mint_vSmartTags order by CategoryCode asc";

//     sqlclient.connect(conn, function (connectionerr) {
//         if (connectionerr) {
//             console.log('error connecting: ' + connectionerr.stack);
//             res.send("DB_ERROR");
//         }
//         var sqlrequest = new sqlclient.Request();
//         sqlrequest.query(query, function (err, result) {
//             if (err) {
//                 console.log(err)
//             }
//             sqlclient.close();
//             res.send(result);
//         });
//     });
// });

module.exports = router;

