var express = require('express');
var router = express.Router();
var con = require('./connection.js');
//MSSQL
var sqlclient = require("mssql");

router.get('/getLossDetailData', function (req, res, next) {

    var conn=con.connection(req.query.selectDate ,req.query.shift)
    
    var query =" select lMINTEventId, tDate, sShift, WorkcellDesc, (CONVERT(varchar(50),lSeconds)) as lSeconds,"+
	 " tStart, tEnd, LossDesc from MINT_HUL_Events where (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "')"+
	 " and (WorkcellDesc = '" + req.query.machine + "') and (lMINTEventId like 'D%') and (lSeconds > '5') order by tStart desc";

     sqlclient.connect(conn, function (connectionerr) {

         if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});


module.exports = router;

