var express = require('express');
var router = express.Router();
var path = require('path');
//Database configuration file
var DBconfig = require('../../config.json');

var sqlclient = require("mssql");
var connectionString = '';
// var mainconfing=DBconfig.connectionString;
// var confing=DBconfig.connectionStringWarehouse;

var dateTime = require('node-datetime');

router.get('/getconnection', function (req, res, next) {

	if (req.query.today) {
		var today1 = req.query.today
	}
	else {
		var dt = dateTime.create();
		var today1 = dt.format('Y-m-d');
	}
	if (req.query.selectShift == req.query.sShift && today1 == req.query.selectDate) {
		connectionString = DBconfig.connectionString;
		res.send(connectionString);
	}
	else {
		connectionString = DBconfig.connectionStringWarehouse;
		res.send(connectionString);
	}
});

router.get('/getWorkcell', function (req, res, next) {

	if (req.query.today) {
		var today1 = req.query.today
	} else {
		var today1 = dt.format('Y-m-d');
	}
	if (req.query.selectShift == req.query.sShift && req.query.date == today1) {
		console.log("current DB " + DBconfig.connectionString);
		connectionString = DBconfig.connectionString;

		var query = "select distinct WorkcellDesc as MachineName from MINT_ActivityAreaTreeDetails1";
	}
	else {
		console.log("wearehouseDB DB " + DBconfig.connectionStringWarehouse);
		connectionString = DBconfig.connectionStringWarehouse;

		var query = "select distinct WorkcellDesc as MachineName from [MINT_HUL_Shift_MMPReport] where sShift='" + req.query.selectShift + "' and tDate='" + req.query.date + "'  ";
	}

	// connect to your database
	sqlclient.connect(connectionString, function (connectionerr) {

		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		// create Request object
		var sqlrequest = new sqlclient.Request();

		// query to the database and get the records
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			// send records as a response
			sqlclient.close();
			res.send(result);

		});
	});
});

router.get('/getOEEdata', function (req, res, next) {

	var query = "select top 1 * from MINT_HUL_Shift_MMPReport where (WorkcellDesc ='" + req.query.machine + "') and (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "') order by tDate desc";

	// connect to your database
	sqlclient.connect(connectionString, function (connectionString) {
		if (connectionString) {
			console.log('error connecting: ' + connectionString.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/getMashineStatedata', function (req, res, next) {

	var query = "select top 1 sCategory, lSeconds from MINT_MachineState where (WorkcellDesc ='" + req.query.machine + "') and (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "') order by lOEEEventId desc";

	sqlclient.connect(connectionString, function (connectionString) {
		if (connectionString) {
			console.log('error connecting: ' + connectionString.stack);
			res.send("DB_ERROR");
		}
		// create Request object
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/getGraphData', function (req, res, next) {

	// var query = "select tStart, tEnd, CLDCount , kWh , dOEE from MINT_OEE where ((WorkcellDesc = '" + req.query.machine + 
	// "') and (tDate = '2020-11-24') and (sShift = 'Shift 1')) order by tStart asc";

	var query = "select tStart, tEnd, CLDCount , kWh , dOEE  from MINT_OEE where ((WorkcellDesc = '" + req.query.machine + "') and (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "')) order by tStart asc";

	// connect to your database
	sqlclient.connect(connectionString, function (connectionString) {

		if (connectionString) {
			console.log('error connecting: ' + connectionString.stack);
			res.send("DB_ERROR");
		}
		// create Request object
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/gettime', function (req, res, next) {

	// var query = "select dTotal from MINT_HUL_Shift_MMPReport where (WorkcellDesc = '" + req.query.machine +
	//  "') and (tDate = '2020-11-24') and (sShift = 'Shift 1') order by tDate desc ";

	var query = "select dTotal from MINT_HUL_Shift_MMPReport where (WorkcellDesc = '" + req.query.machine + "') and (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "') order by tDate desc ";

	sqlclient.connect(connectionString, function (connectionString) {
		if (connectionString) {
			console.log('error connecting: ' + connectionString.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/gettop5loss', function (req, res, next) {

	// var query = "select LossDesc, sum(TotalSec) as TotalSec, sum(TotalCount) as TotalCount from MINT_HUL_Shift_EventSummary where (WorkcellDesc = '" + req.query.machine + "') and (tDate = '2020-11-24') and (sShift = 'Shift 1') group by LossDesc, WorkcellDesc, tDate, sShift order by TotalSec desc";

	var query = "select LossDesc, sum(TotalSec) as TotalSec, sum(TotalCount) as TotalCount from MINT_HUL_Shift_EventSummary where (WorkcellDesc = '" + req.query.machine + "') and (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "') group by LossDesc, WorkcellDesc, tDate, sShift order by TotalSec desc";

	sqlclient.connect(connectionString, function (connectionString) {
		if (connectionString) {
			console.log('error connecting: ' + connectionString.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/getProductionData', function (req, res, next) {
	
	var query = "With sumdata as (select tStart,SUM(CLDCount) asum,ROW_NUMBER() OVER(ORDER BY tStart ASC) " +
		" AS rownum  from MINT_OEE where (WorkcellDesc = '" + req.query.machine +
		"') and (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift +
		"') group by tStart ) " +
		" SELECT (SELECT SUM(asum) FROM sumdata c2 WHERE c2.rownum <= c1.rownum) CLDCount, " +
		" (right('0' + cast(datepart(hh,tStart)  as varchar(2)), 2)+ ':'+right('0' + cast(datepart(MINUTE,tStart)  as varchar(2)), 2)) as time " +
		" FROM sumdata c1";

	// connect to your database
	sqlclient.connect(connectionString, function (connectionString) {
		if (connectionString) {
			console.log('error connecting: ' + connectionString.stack);
			res.send("DB_ERROR");
		}
		// create Request object
		var sqlrequest = new sqlclient.Request();
		// query to the database and get the records
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			// send records as a response
			sqlclient.close();
			res.send(result);
		});
	});
});

//process 
router.get('/getBoon1and2Data', function (req, res, next) {

	var preshift = req.query.preshift;
	var sShiftPrevious = req.query.sShiftPrevious;
	var sShiftCurrent = req.query.sShiftCurrent;

	if (req.query.shift == req.query.sShift && req.query.currdate == req.query.selectDate) {
		var connectionStr = DBconfig.connectionString;
		var query = "select tShift,sShift,sFolder,max(dEnd) as val from [OEEEvent]where tShift='" + req.query.currshift +
			"' group by sFolder,sShift,tShift union all select tShift,sShift,sFolder,max(dEnd) as val " +
			" from [OEEEvent]where tShift='" + preshift + "' group by sFolder,sShift,tShift";

		// connect to your database
		sqlclient.connect(connectionStr, function (connectionString) {
			if (connectionString) {
				console.log('error connecting: ' + connectionString.stack);
				res.send("DB_ERROR");
			}
			// create Request object
			var sqlrequest = new sqlclient.Request();
			// query to the database and get the records
			sqlrequest.query(query, function (err, result) {
				if (err) {
					console.log(err)
				}
				// send records as a response
				sqlclient.close();
				var resultArr = JSON.parse(JSON.stringify(result.recordset));
				if (resultArr.length > 0) {
					var preData = resultArr.filter(ro => String(ro.tShift).includes(sShiftPrevious));
					if (preData.length == 0) {
						var con = DBconfig.connectionStringWarehouse;
						var query = "select tShift,sShift,sFolder,max(dEnd) as val " +
							" from [OEEEvent]where tShift='" + preshift + "' group by sFolder,sShift,tShift";

						sqlclient.connect(con, function (connectionString) {
							if (connectionString) {
								console.log('error connecting: ' + connectionString.stack);
								res.send("DB_ERROR");
							}
							var sqlrequest = new sqlclient.Request();
							sqlrequest.query(query, function (err, data) {
								if (err) {
									console.log(err)
								}
								sqlclient.close();
								var resdata = JSON.parse(JSON.stringify(data.recordset));
								if (resdata.length > 0) {
									var cnt = resdata.length;
									for (var i = 0; i < resdata.length; i++) {
										resultArr[cnt] = resdata[i];
										cnt++;
									}
									res.send(resultArr);
								}

							});
						});
					}
					else {
						res.send(resultArr);
					}
				}
			});
		});
	}
	else {
		var connectionStr = DBconfig.connectionStringWarehouse;
		var query = "select tShift,sShift,sFolder,max(dEnd) as val from [OEEEvent]where tShift='" + req.query.currshift +
			"' group by sFolder,sShift,tShift union all select tShift,sShift,sFolder,max(dEnd) as val " +
			" from [OEEEvent]where tShift='" + preshift + "' group by sFolder,sShift,tShift";

		// connect to your database
		sqlclient.connect(connectionStr, function (connectionString) {
			if (connectionString) {
				console.log('error connecting: ' + connectionString.stack);
				res.send("DB_ERROR");
			}
			// create Request object
			var sqlrequest = new sqlclient.Request();
			// query to the database and get the records
			sqlrequest.query(query, function (err, result) {
				if (err) {
					console.log(err)
				}
				// send records as a response
				sqlclient.close();
				var resultArr = JSON.parse(JSON.stringify(result.recordset));
				if (resultArr.length > 0) {
					var preData = resultArr.filter(ro => String(ro.tShift).includes(sShiftPrevious));
					var currData = resultArr.filter(ro => String(ro.tShift).includes(sShiftCurrent));

					if (preData.length == 0) {
						var con = DBconfig.connectionString;
						var query = "select tShift,sShift,sFolder,max(dEnd) as val " +
							" from [OEEEvent]where tShift='" + preshift + "' group by sFolder,sShift,tShift";

						sqlclient.connect(con, function (connectionString) {
							if (connectionString) {
								console.log('error connecting: ' + connectionString.stack);
								res.send("DB_ERROR");
							}
							var sqlrequest = new sqlclient.Request();
							sqlrequest.query(query, function (err, data) {
								if (err) {
									console.log(err)
								}
								sqlclient.close();
								var resdata = JSON.parse(JSON.stringify(data.recordset));
								if (resdata.length > 0) {
									var cnt = resdata.length;
									for (var i = 0; i < resdata.length; i++) {
										resultArr[cnt] = resdata[i];
										cnt++;
									}
									res.send(resultArr);
								}
								else {
									res.send(resdata);
								}
							});
						});
					}
					else if (currData.length == 0) {
						var con = DBconfig.connectionString;
						var query = "select tShift,sShift,sFolder,max(dEnd) as val " +
							" from [OEEEvent]where tShift='" + req.query.currshift + "' group by sFolder,sShift,tShift";

						sqlclient.connect(con, function (connectionString) {
							if (connectionString) {
								console.log('error connecting: ' + connectionString.stack);
								res.send("DB_ERROR");
							}
							var sqlrequest = new sqlclient.Request();
							sqlrequest.query(query, function (err, data) {
								if (err) {
									console.log(err)
								}
								sqlclient.close();
								var resdata = JSON.parse(JSON.stringify(data.recordset));
								if (resdata.length > 0) {
									var cnt = resdata.length;
									for (var i = 0; i < resdata.length; i++) {
										resultArr[cnt] = resdata[i];
										cnt++;
									}
									res.send(resultArr);
								}
								else {
									res.send(resdata);
								}
							});
						});
					}
					else {
						res.send(resultArr);
					}
				}

			});
		});
	}

});

//
router.get('/getOPEChart', function (req, res, next) {

	var query = "select e.sEventDesc,e.LossDesc,sum(ROUND((TotalSec/60),2)) as LMin,s.RootCause "+
	" from MINT_HUL_Shift_EventSummary e left outer join Mint_vSmartTags s on "+
	" e.sEventDesc=s.LossCode and e.WorkcellDesc=s.MachineName where e.tDate='" + req.query.selectDate + 
	"' and e.sShift='" + req.query.shift +"' and e.WorkcellDesc='" + req.query.machine +
	"' group by e.sEventDesc,e.LossDesc,s.RootCause";

	sqlclient.connect(connectionString, function (connectionString) {
		if (connectionString) {
			console.log('error connecting: ' + connectionString.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

module.exports = router;
