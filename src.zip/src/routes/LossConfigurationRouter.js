var express = require('express');
var router = express.Router();
var path = require('path');
var DBconfig = require('../../config.json');
var connectionString =DBconfig.connectionString;
//MSSQL
var sqlclient = require("mssql");

//#region Reciept data
router.get('/getLossData', function (req, res, next) {
	if(req.query.machine)
	{
		var query = "select * from Mint_vSmartTags where MachineCode='"+req.query.machine+"' order by LossCode asc";
	}
	else{
		var query = "select * from Mint_vSmartTags order by LossCode asc";
	}
    
    sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.post('/InsertLossData', function (req, res, next) {
	var query = "INSERT INTO [Mint_SmartTags] ([LossCode],[SmartTag],[CategoryCode],[MachineCode])"+
	" VALUES ('"+ req.body.losscode +"','" + req.body.smartag + "','" + req.body.catgrycode + "'"+
	",'" + req.body.machinecode + "')"; 

    sqlclient.connect(connectionString, function (connectionerr) {	
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/getcategorycode', function(req, res, next){
    
	var query = "select distinct[CategoryCode],[MMPLossCodeDesc] from Mint_vSmartTags";
 
    sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/getMachineCode', function(req, res, next){
    
	var query = "select distinct [WorkcellID] as MachineCode,WorkcellDesc as MachineName from [MINT_ActivityAreaTreeDetails1]";

    sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.post('/updateLossData', function (req, res, next) {

	var query = "Update [Mint_SmartTags] set [SmartTag]='" + req.body.smartag + "',[CategoryCode] ='"+ req.body.catgrycode+"',[MachineCode] ='"+req.body.machinecode+"' where [LossCode] ='" + req.body.losscode + "'";
				
	 sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});


router.post('/deleteLossConfig', function (req, res, next) {
	
	var query = "DELETE FROM [Mint_SmartTags] "+
	" where [LossCode]='" + req.body.losscode + "'";
	
    sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});


router.get('/rootcause', function(req, res, next){
    
    var query ="select * from MINT_HUL_MMPLossCode where MMPLossCodeID= "+req.query.catgrycode +" ";

    sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

//
router.get('/checkLossCodeExist', function (req, res, next) {
	
	var query = "select * from  Mint_SmartTags  where [LossCode]=" + req.query.losscode + 
	" and [MachineCode]=" + req.query.machine +"";
    sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});
//#endregion
module.exports = router;