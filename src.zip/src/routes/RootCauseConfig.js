var express = require('express');
var router = express.Router();
var path = require('path');
var DBconfig = require('../../config.json');

var sqlclient = require("mssql");

var connectionString = DBconfig.connectionString;

//#region 
router.get('/getRootCauseData', function (req, res, next) {

	var query = "select [MINT_HUL_MMPCode].[MMPCodeDesc] as details, " +
		" [MINT_HUL_MMPLossCode].* from [MINT_HUL_MMPCode],[MINT_HUL_MMPLossCode] " +
		" where [MINT_HUL_MMPCode].[MMPCodeID] = [MINT_HUL_MMPLossCode].[MMPCodeID] " +
		" and [MINT_HUL_MMPLossCode].[Type]='" + req.query.type + "' order by [MINT_HUL_MMPLossCode].[MMPLossCodeID] asc";

	sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.post('/addRootCauseData', function (req, res, next) {

	var query = "INSERT INTO [MINT_HUL_MMPLossCode] ([MMPLossCodeID],[MMPLossCodeDesc],[MMPCodeID],[RootCause1]" +
		",[RootCause2],[RootCause3],[RootCause4],[RootCause5],[RootCause6],Type)" +
		" VALUES ('" + req.body.mmplosscode + "','" + req.body.mmplossdesc + "','" + req.body.mmpcode + "'" +
		",'" + req.body.rootcause1 + "','" + req.body.rootcause2 + "','" + req.body.rootcause3 + "'" +
		",'" + req.body.rootcause4 + "','" + req.body.rootcause5 + "', '" + req.body.rootcause6 + "', '" + req.body.type + "')";

	sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/getMMPCodeID', function (req, res, next) {
	var query = "SELECT [MMPCodeID],[MMPCodeDesc] FROM MINT_HUL_MMPCode";
	sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.post('/updateRootCauseData', function (req, res, next) {

	var query = "Update MINT_HUL_MMPLossCode set [MMPCodeID]='" + req.body.mmpcode +
		"',[MMPLossCodeDesc]='" + req.body.mmplossdesc + "',[RootCause1] ='" + req.body.rootcause1 +
		"',[RootCause2] ='" + req.body.rootcause2 + "',[RootCause3]='" + req.body.rootcause3 +
		"',[RootCause4]='" + req.body.rootcause4 + "',[RootCause5]='" + req.body.rootcause5 +
		"',[RootCause6]='" + req.body.rootcause6 + "', Type='" + req.body.type + 
		"' where [MMPLossCodeID]='" + req.body.mmplosscode + "'";

	sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.post('/deleteRootCauseData', function (req, res, next) {

	var query = "DELETE FROM  MINT_HUL_MMPLossCode " +
		" where [MMPLossCodeID]='" + req.body.mmplosscode + "'";

	sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});

router.get('/singleentry', function (req, res, next) {

	var query = "select * from  MINT_HUL_MMPLossCode  where [MMPLossCodeID]='" + req.query.mmplosscode + "'";
	sqlclient.connect(connectionString, function (connectionerr) {
		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			if (err) {
				console.log(err)
			}
			sqlclient.close();
			res.send(result);
		});
	});
});
//#endregion
module.exports = router;