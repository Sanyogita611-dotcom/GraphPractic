var express = require('express');
var router = express.Router();
var DBconfig = require('../../config.json');
var connectionString = DBconfig.connectionString;
//MSSQL
var sqlclient = require("mssql");

router.get('/getAllMachine', function (req, res, next) {

    var query = " select * from [MINT_ActivityAreaTreeDetails1]";
    // connect to your database
    sqlclient.connect(connectionString, function (connectionerr) {

        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        // create Request object
        var sqlrequest = new sqlclient.Request();

        // query to the database and get the records
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            // var rowsAffected = JSON.parse(JSON.stringify(result.rowsAffected));
            sqlclient.close();
            res.send(result);
        });
    });
});


module.exports = router;

