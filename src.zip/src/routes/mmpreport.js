var express = require('express');
var router = express.Router();
var con = require('./connection.js');
var sqlclient = require("mssql");
var DBconfig = require('../../config.json');
var connectionstr = DBconfig.connectionString;

router.get('/GetMMPreportData', function (req, res, next) {

    var conn = con.connection(req.query.selectDate, req.query.strShift)

    var query = "select * from MINT_HUL_Shift_MMPReport where tDate='" + req.query.selectDate + "' and sShift in(" + req.query.strShift + ") " +
        " and WorkcellDesc in(" + req.query.str + ")  order by WorkcellDesc asc,sShift asc";

    sqlclient.connect(conn, function (connectionerr) {

        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});
//

router.get('/getMachineName', function (req, res, next) {
    var conn = con.connection(req.query.selectDate, req.query.strShift)
    var query = "select distinct WorkcellDesc from MINT_HUL_Shift_MMPReport"; 
    // where tDate='" + req.query.selectDate + "' and sShift in(" + req.query.str + ") order by WorkcellDesc asc";

    sqlclient.connect(conn, function (connectionerr) {
	
		if (connectionerr) 
		{
			console.log(connectionerr);
		}
        var sqlrequest = new sqlclient.Request();
           
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			// send records as a response
			sqlclient.close();
			res.send(result);
		});
	});
});
module.exports = router;

