var express = require('express');
var router = express.Router();
var sortJsonArray = require('sort-json-array');
var path = require('path');
//Database configuration file
var DBconfig = require('../../config.json');

//MSSQL
var sqlclient = require("mssql");

var connectionString =DBconfig.connectionString;

//#region Reciept data
router.get('/getData', function (req, res, next) {
	
	var query = "Select * from  Mint_SKUDetails ORDER BY [SKUId] asc";

	// connect to your database
    sqlclient.connect(connectionString, function (connectionerr) {
	
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        // create Request object
        var sqlrequest = new sqlclient.Request();
           
        // query to the database and get the records
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			// send records as a response
			sqlclient.close();
			res.send(result);
            
		});
	});
});

router.post('/addData', function (req, res, next) {
	
	var query = "INSERT INTO Mint_SKUDetails ([SKUName],[SKUTabletPerCLD],[DesignSpeed]"+
	",[SKUGrammge],[SKUPmGrammage], [SKUTarget])"+ 
	" VALUES ('" + req.body.configname + "','" + req.body.cld + "'"+
	",'" + req.body.speed + "','" + req.body.gramtablet + "','" + req.body.grampm + "'"+
	",'" + req.body.target + "')";

	// connect to your database
    sqlclient.connect(connectionString, function (connectionerr) {
	
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        // create Request object
        var sqlrequest = new sqlclient.Request();
           
        // query to the database and get the records
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			// send records as a response
			sqlclient.close();
			res.send(result);
            
		});
	});
});

router.post('/updateData', function (req, res, next) {

	var query = "Update Mint_SKUDetails set [SKUName]='" + req.body.configname + 
	"',[SKUTabletPerCLD]='" + req.body.cld + "',[DesignSpeed] ='"+ req.body.speed+
	"',[SKUGrammge] ='"+req.body.gramtablet+"',[SKUPmGrammage]='"+req.body.grampm+
	"',[SKUTarget]='" +req.body.target+ "' where SKUId=" + req.body.skuid+"";
				
	// connect to your database
    sqlclient.connect(connectionString, function (connectionerr) {
	
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        // create Request object
        var sqlrequest = new sqlclient.Request();
           
        // query to the database and get the records
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			// send records as a response
			sqlclient.close();
			res.send(result);
            
		});
	});
});

router.post('/deleteData', function (req, res, next) {
	
	var query = "DELETE FROM Mint_SKUDetails "+
	" where SKUId=" + req.body.skuid + "";
	
	// connect to your database
    sqlclient.connect(connectionString, function (connectionerr) {
	
		if (connectionerr) 
		{
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
        // create Request object
        var sqlrequest = new sqlclient.Request();
           
        // query to the database and get the records
        sqlrequest.query(query, function (err, result) {
            if (err) {
				console.log(err)
			}
			// send records as a response
			sqlclient.close();
			res.send(result);
            
		});
	});
});
//#endregion

module.exports = router;