var express = require('express');
var router = express.Router();

var sqlclient = require("mssql");
var DBconfig = require('../../config.json');
var connectionString = DBconfig.connectionString;


router.post('/InsertUserTrackDetail', function (req, res, next) {

    var query = "Insert into Mint_UserTracking([PageName],[DateTime],[UserName]) " +
        " values('" + req.body.pagename + "', '" + req.body.datetime + "','" + req.body.username + "')";

    sqlclient.connect(connectionString, function (connectionerr) {

        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        // create Request object
        var sqlrequest = new sqlclient.Request();

        sqlrequest.query(query, function (err, result) {

            if (err) {
                console.log(err)
            }

            sqlclient.close();
            res.send(result);
        });
    });
})

//getUserTrackData
router.get('/getUserTrackData', function (req, res, next) {

    var query = " select UserName,CONVERT(date,[DateTime]) as [DateTime],count(PageName) as PageCount,PageName  FROM [Mint_UserTracking] group by PageName,UserName,CONVERT(date,[DateTime]) ";

    sqlclient.connect(connectionString, function (connectionerr) {

        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        // create Request object
        var sqlrequest = new sqlclient.Request();

        sqlrequest.query(query, (err, result) => {

            sqlclient.close();
            if (err) {
                res.send(err);
            }

            res.send(result);
        })
    })
});
module.exports = router;