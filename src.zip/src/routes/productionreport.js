var express = require('express');
var router = express.Router();
var con = require('./connection.js');
//MSSQL
var sqlclient = require("mssql");

router.get('/getProductionDetailData', function (req, res, next) {

    var conn=con.connection(req.query.selectDate ,req.query.shift)
    
    var query =	  " select * from [MINT_HUL_Shift_ProductionSummary] where (tDate = '" + req.query.selectDate + "') and"
	 + " (sShift = '" + req.query.shift + "') and (WorkcellDesc = '" + req.query.machine + "')";

     sqlclient.connect(conn, function (connectionerr) {

         if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});


module.exports = router;

