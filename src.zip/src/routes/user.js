var express = require('express');
var router = express.Router();
var path = require('path');
var sqlclient = require("mssql");
var md5 = require('md5');
var DBconfig = require('../../config.json');
var connectionString = DBconfig.connectionString;

router.get('/getusers', function (req, res, next) {

	var query = "SELECT * FROM Mint_User ORDER BY RowId";

	sqlclient.connect(connectionString, function (connectionerr) {

		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		// create Request object
		var sqlrequest = new sqlclient.Request();

		sqlrequest.query(query, (err, recordset) => {

			sqlclient.close();
			if (err) {
				res.send(err);
			}
			else {
				res.send(recordset);
			}
		})
	})
});
//
router.post('/CreatUser', function (req, res, next) {
	var Password = md5(req.body.Password);
	var query = "Insert into Mint_User(Email,[Password],MobileNo,Status,DateTime) values('" + req.body.Email +
		"','" + Password + "','" + req.body.mobile + "'," +
		" '" + req.body.Status + "','" + req.body.date + "')";

	sqlclient.connect(connectionString, function (connectionerr) {

		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		// create Request object
		var sqlrequest = new sqlclient.Request();

		sqlrequest.query(query, function (err, result) {

			if (err) {
				console.log(err)
			}

			//var rowsAffected = JSON.parse(JSON.stringify(result.rowsAffected));

			sqlclient.close();
			res.send(result);
		});
	});
})
//
router.post('/UpdateUser', function (req, res, next) {

	var query = "Update Mint_User set Email='" + req.body.Email + "'," +
		"MobileNo='" + req.body.mobile + "',Status='" + req.body.Status + "',DateTime='" + req.body.date +
		"' where RowId=" + req.body.userid + " ";


	sqlclient.connect(connectionString, function (connectionerr) {

		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		// create Request object
		var sqlrequest = new sqlclient.Request();
		sqlrequest.query(query, function (err, result) {
			//	var data = JSON.parse(JSON.stringify(result.recordset));
			if (err) {
				console.log(err)
			}
			//	var rowsAffected = JSON.parse(JSON.stringify(result.rowsAffected));
			sqlclient.close();
			res.send(result);
		});
	});
})

router.post('/deleteUser', function (req, res, next) {

	var query = "Delete from Mint_User where RowId ='" + req.body.userid + "'";
	//params = [req.body.userid];

	sqlclient.connect(connectionString, function (connectionerr) {

		if (connectionerr) {
			console.log('error connecting: ' + connectionerr.stack);
			res.send("DB_ERROR");
		}
		// create Request object
		var sqlrequest = new sqlclient.Request();

		//sqlrequest.query(query, params, (err, recordset) => {
		sqlrequest.query(query, function (err, recordset) {
			sqlclient.close();

			if (err) {
				res.send(err);
			}
			else {
				res.send(recordset);
			}
		})
	})
});

module.exports = router;