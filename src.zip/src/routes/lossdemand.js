var express = require('express');
var router = express.Router();
var DBconfig = require('../../config.json');
var connectionString = DBconfig.connectionStringWarehouse;
var sqlclient = require("mssql");


router.get('/getMachineNameLossDemand', function (req, res, next) {
    if (req.query.type != '-Select Machine type-') {
        if (req.query.type == 'Akash_PackingMachine') {
            var query = "select distinct WorkcellDesc from MINT_HUL_Shift_MMPReport " +
                " where tDate between '" + req.query.yesdate + "' and '" + req.query.date +
                "' and WorkcellDesc like 'Akash%'";
        }
        else if (req.query.type == 'Shubham_PackingMachine') {
            var query = "select distinct WorkcellDesc from MINT_HUL_Shift_MMPReport " +
                " where tDate between '" + req.query.yesdate + "' and '" + req.query.date +
                "' and WorkcellDesc like 'Shubham%'";
        }
        else if (req.query.type == 'Hassia') {
            var query = "select distinct WorkcellDesc from MINT_HUL_Shift_MMPReport " +
            " where tDate between '" + req.query.yesdate + "' and '" + req.query.date +
            "' and WorkcellDesc like 'Hassia%'";        }
        else {
            var query = "select distinct WorkcellDesc from MINT_HUL_Shift_MMPReport " +
                " where tDate between '" + req.query.yesdate + "' and '" + req.query.date + "'";
                //"' and WorkcellDesc like 'Process%'";
        }
    }
    else {
        var query = "select distinct WorkcellDesc from MINT_HUL_Shift_MMPReport where tDate between '" + req.query.yesdate + "' and '" + req.query.date + "' order by WorkcellDesc asc";
    }
    sqlclient.connect(connectionString, function (connectionerr) {
        if (connectionerr) {
            console.log(connectionerr);
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

//shiftloss
router.get('/DemandShiftLossSummeryData', function (req, res, next) {

    var query = " select * from MINT_HUL_Shift_EventSummary where tDate " +
        "between '" + req.query.FromDate + "' and '" + req.query.ToDate + "' and " +
        "  WorkcellDesc in(" + req.query.line + ") and  sShift in(" + req.query.shift + ") order by tDate asc ";

    sqlclient.connect(connectionString, function (connectionerr) {

        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});
//
//LossDetailData
router.get('/DemandLossDetailData', function (req, res, next) {

    var query = " select lMINTEventId, tDate, sShift, WorkcellDesc, (CONVERT(varchar(50),lSeconds))" +
        " as lSeconds, tStart, tEnd, LossDesc from MINT_HUL_Events where tDate between " +
        "'" + req.query.FromDate + "' and '" + req.query.ToDate + "' and  sShift in(" + req.query.shift + ") and " +
        " WorkcellDesc in(" + req.query.line + ") and (lMINTEventId like 'D%') and (lSeconds > '5')" +
        " order by tStart asc";

    sqlclient.connect(connectionString, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});
//
//MMP report
router.get('/DemandMMPreportData', function (req, res, next) {

    var query = "select * from MINT_HUL_Shift_MMPReport where tDate between '" + req.query.FromDate + "' and '" + req.query.ToDate + "' " +
        " and  WorkcellDesc in( " + req.query.line + " )  and  sShift in(" + req.query.shift + ") order by WorkcellDesc , tdate asc";

    sqlclient.connect(connectionString, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

router.get('/DemandAllLossesData', function (req, res, next) {

    var query = " select * from [MINT_HUL_Shift_EventSummary] where tDate between '" + req.query.FromDate + "' and '" + req.query.ToDate + "' " +
        " and WorkcellDesc in(" + req.query.line + ") and  sShift in(" + req.query.shift + ")";

    sqlclient.connect(connectionString, function (connectionerr) {

        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

//
//produnction detail
router.get('/DemandProductionDetailData', function (req, res, next) {

    var query = "select * from MINT_HUL_Shift_ProductionSummary where tDate between '" + req.query.FromDate +
        "' and  '" + req.query.ToDate + "' and sShift in(" + req.query.shift + ") and WorkcellDesc in(" + req.query.line + ")";

    sqlclient.connect(connectionString, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});
//
//no touch
router.get('/Demandnotouch', function (req, res, next) {

    var running = "Activity Area Running - Point";
    var query = "select tDate,WorkcellDesc,sShift,max(lSeconds)as maxlSeconds,avg(lSeconds)as avglSeconds,min(lSeconds)as minlSeconds," +
        "(count(sCategory)-1) as count from MINT_MachineState where tDate between '" + req.query.FromDate + "'" +
        " and '" + req.query.ToDate + "' and WorkcellDesc in(" + req.query.line + ") and" +
        " (sCategory='" + running + "') and  sShift in(" + req.query.shift + ") group by tDate,WorkcellDesc,sShift";

    sqlclient.connect(connectionString, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});
//
router.get('/NoTouchReport', function (req, res, next) {

    var query = "select * from MINT_NoTouchOnDemand where tDate between '" + req.query.FromDate + "' " +
        "and '" + req.query.ToDate + "' and  WorkcellDesc in(" + req.query.line + ") and  sShift in(" + req.query.shift + ")";

    sqlclient.connect(connectionString, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});

module.exports = router;

