var express = require('express');
var router = express.Router();
var con = require('./connection.js');
var DBconfig = require('../../config.json');
var connectionString = DBconfig.connectionString;
//MSSQL
var sqlclient = require("mssql");

router.get('/getShiftLossSummeryData', function (req, res, next) {

    var conn = con.connection(req.query.selectDate, req.query.shift)
    var query = " select * from MINT_HUL_Shift_EventSummary where (tDate = '" + req.query.selectDate + "') and (sShift = '" + req.query.shift + "') and (WorkcellDesc = '" + req.query.machine + "')";
  
    sqlclient.connect(conn, function (connectionerr) {

        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        // create Request object
        var sqlrequest = new sqlclient.Request();

        // query to the database and get the records
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            // var rowsAffected = JSON.parse(JSON.stringify(result.rowsAffected));
            sqlclient.close();
            res.send(result);
        });
    });
});
//
router.get('/getAllSmrtTags', function (req, res, next) {

   // var conn = con.connection(req.query.selectDate, req.query.shift)
    var query = "select * from Mint_vSmartTags";

    sqlclient.connect(connectionString, function (connectionerr) {
        if (connectionerr) {
            console.log('error connecting: ' + connectionerr.stack);
            res.send("DB_ERROR");
        }
        var sqlrequest = new sqlclient.Request();
        sqlrequest.query(query, function (err, result) {
            if (err) {
                console.log(err)
            }
            sqlclient.close();
            res.send(result);
        });
    });
});
module.exports = router;

