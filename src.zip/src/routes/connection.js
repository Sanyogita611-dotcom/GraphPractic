
var DBconfig = require('../../config.json');
var dateTime = require('node-datetime');

function connection(selectDate, selectShift) {
    var today = new Date();
    var dateFormat = "Y-m-d";
    var datetimeformat = "Y-m-d H:i:s";

    var Edate = format(today, datetimeformat);
    tDate = format(today, dateFormat);

    //Shift value
    var lblshift = tDate + " " + "07:00:00";
    var shift2 = tDate + " " + "15:00:00";
    var shift3 = tDate + " " + "23:00:00";
    var midnight = tDate + " " + "23:59:59";

    var newday = new Date();
    newday.setDate(newday.getDate() - 1);
    var d = newday.getDate();
    var m = newday.getMonth() + 1;
    var y = newday.getFullYear();

    newday = y + "-" + m + "-" + d + " " + "23:00:00";

    if (new Date(Edate).valueOf() >= new Date(lblshift).valueOf() &&
        new Date(Edate).valueOf() < new Date(shift2).valueOf()) {

        sShift = "Shift1";

    }
    else if (new Date(Edate).valueOf() >= new Date(shift2).valueOf() &&
        new Date(Edate).valueOf() < new Date(shift3).valueOf()) {
        sShift = "Shift2";
    }
    else if (new Date(Edate).valueOf() >= new Date(newday).valueOf() && new Date(Edate).valueOf() < new Date(lblshift).valueOf()
        || new Date(Edate).valueOf() >= new Date(shift3).valueOf()) {
        if (new Date(Edate).valueOf() >= new Date(shift3).valueOf()
            && new Date(Edate).valueOf() < new Date(midnight).valueOf()
        ) {
            sShift = "Shift3";
        }
        if (new Date(Edate).valueOf() >= new Date(newday).valueOf() && new Date(Edate).valueOf() < new Date(lblshift).valueOf()) {
            sShift = "Shift3";
        }
    }

    if (selectShift == sShift && tDate == selectDate) {
      var  connectionString = DBconfig.connectionString;
      console.log('connectionString'+JSON.stringify(connectionString));
      return(connectionString);
    }
    else {
       var connectionString = DBconfig.connectionStringWarehouse;
       console.log('connectionString'+JSON.stringify(connectionString));
        return(connectionString);
    }
}

//#region DateFunctions

function toDate(date) {
    if (date === void 0) {
        return new Date(0);
    }
    if (isDate(date)) {
        return date;
    } else {
        return new Date(parseFloat(date.toString()));
    }
}

function isDate(date) {
    return (date instanceof Date);
}

function format(date, format) {
    var d = toDate(date);
    return format
        .replace(/Y/gm, d.getFullYear().toString())
        .replace(/m/gm, ('0' + (d.getMonth() + 1)).substr(-2))
        .replace(/d/gm, ('0' + (d.getDate() + 0)).substr(-2))
        .replace(/H/gm, ('0' + (d.getHours() + 0)).substr(-2))
        .replace(/i/gm, ('0' + (d.getMinutes() + 0)).substr(-2))
        .replace(/s/gm, ('0' + (d.getSeconds() + 0)).substr(-2))
        .replace(/v/gm, ('0000' + (d.getMilliseconds() % 1000)).substr(-3));
}
//#endregion


module.exports = {
    connection: connection
}