
var selectedrow, Sdate, Edate, buttonCommon;
$(document).ready(function () {
    debugger;
    buttonCommon = {
        exportOptions: {
            format: {
                body: function (data, row, column, node) {
                    // Strip $ from salary column to make it numeric
                    return column === 5 ?
                        data.replace(/[$,]/g, '') :
                        data;
                }
            }
        }
    }

    var today = new Date();
    var yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);

    var dateFormat = "Y-m-d";

    date = format(today, dateFormat);
    yesdate = format(yesterday, dateFormat);

    $("#date_from").val(yesdate);
    $("#date_To").val(date);
    getMachineNameLossDemand();
    $('#date_from').on('change', function (e) {
        getMachineNameLossDemand();
    });
    $('#date_To').on('change', function (e) {
        getMachineNameLossDemand();
    });
    //$('#ddltype').on('change', function (e) {
        getMachineNameLossDemand();
   // })

    $("#EventDetails").hide();
    $("#MMPTable").hide();
    $("#notouchreport").hide();
    $("#ProductionDetail").hide();
    $("#lossdetail").hide();

    $('#ddlreport').on('change', function (e) {
        var Report = document.getElementById("ddlreport").value;
        getMachineNameLossDemand();
        if (Report == "Loss Summary Report") {
            $("#EventDetails").show();
            $("#ProductionDetail").hide();
            $("#MMPTable").hide();
            $("#lossdetail").hide();
            $("#notouchreport").hide();
            $("#divtype").hide();
        }
        else if (Report == "MMP Report") {
            $("#EventDetails").hide();
            $("#MMPTable").show();
            $("#lossdetail").hide();
            $("#ProductionDetail").hide();
            $("#notouchreport").hide();
            $("#divtype").show();
        }
        else if (Report == "No Touch Report") {
            $("#EventDetails").hide();
            $("#MMPTable").hide();
            $("#notouchreport").show();
            $("#lossdetail").hide();
            $("#ProductionDetail").hide();
            $("#divtype").hide();
        }
        else if (Report == "Production Report") {
            $("#EventDetails").hide();
            $("#MMPTable").hide();
            $("#notouchreport").hide();
            $("#ProductionDetail").show();
            $("#lossdetail").hide();
            $("#divtype").hide();
        }
        else if (Report == "Loss Detail Report") {
            $("#EventDetails").hide();
            $("#MMPTable").hide();
            $("#notouchreport").hide();
            $("#ProductionDetail").hide();
            $("#lossdetail").show();
            $("#divtype").hide();
        }
    });
});

$(document).mouseup(function (e) {
    // if the target of the click isn't the container nor a descendant of the container
    if (!$("#checkboxes").is(e.target) && $("#checkboxes").has(e.target).length === 0) {
        $("#checkboxes").hide();
    }
    if (!$("#checkboxesShift").is(e.target) && $("#checkboxesShift").has(e.target).length === 0) {
        $("#checkboxesShift").hide();
    }
});

var expanded = false, expandedShift = false;
function showCheckboxes() {
    var checkboxes = document.getElementById("checkboxes");
    var checkboxesShift = document.getElementById("checkboxesShift");
    if (!expanded) {
        checkboxes.style.display = "block";
        expanded = true;
    } else {
        checkboxes.style.display = "none";
        expanded = false;
    }
}

function showCheckboxesShift() {
    var checkboxesShift = document.getElementById("checkboxesShift");

    if (!expandedShift) {
        checkboxesShift.style.display = "block";
        expandedShift = true;
    } else {
        checkboxesShift.style.display = "none";
        expandedShift = false;
    }
}

var selectedMenu = "";
function checkOptions() {
    els = document.getElementsByName('line[]');
    var qtChecks = 0;
    selectedMenu = "";
    var labl = '';

    if (els[0].checked) {
        for (var ii = 1; ii < els.length; ii++) {

            els[ii].checked = true;
        }
    }
    if (!els[0].checked) {
        for (var ii = 1; ii < els.length; ii++) {

            els[ii].checked = false;
        }
    }

    for (i = 1; i < els.length; i++) {
        if (els[i].checked) {
            if (qtChecks > 0) {
                selectedMenu += ", "
                labl += ", "
            }
            selectedMenu += els[i].value;
            qtChecks++;
        }
    }
}

var selectedShift = "";
function checkOptionsShift() {
    els = document.getElementsByName('shift[]');
    var qtChecks = 0;
    selectedShift = "";
    var labl = '';

    if (els[0].checked) {
        for (var ii = 1; ii < els.length; ii++) {

            els[ii].checked = true;
        }
    }
    if (!els[0].checked) {
        for (var ii = 1; ii < els.length; ii++) {

            els[ii].checked = false;
        }
    }

    for (i = 1; i < els.length; i++) {
        if (els[i].checked) {
            if (qtChecks > 0) {
                selectedShift += ", "
                labl += ", "
            }
            selectedShift += els[i].value;
            // labl += els[i].labels[0].innerText;

            qtChecks++;
        }
    }
}

function getMachineNameLossDemand() {
    debugger;
    var FromDate = document.getElementById("date_from").value;
    var ToDate = document.getElementById("date_To").value;
   // var type = document.getElementById("ddltype").value;
    var Report = document.getElementById("ddlreport").value;
    if (Report != "MMP Report") {
        type = '-Select Machine type-';
    }
    if (FromDate == "" || FromDate == null || ToDate == "" || ToDate == null) {
        alert('Something Missing Data..');
    } else {
        $.ajax({
            type: 'GET',
            url: "/getMachineNameLossDemand",
            dataType: 'json',
            async: false,
            data: { yesdate: FromDate, date: ToDate },
            success: function (result) {
                var data = JSON.parse(JSON.stringify(result.recordset));
                var html = '';
                $('#checkboxes').empty();
                if (data.length > 0) {
                    html += '<label style="margin-left: 5px;"> &nbsp;';
                    html += '<input type="checkbox" name="line[]" id="line" value="All Lines" onclick="checkOptions();"/> &nbsp;' + "All Lines" +
                        '</label>';

                    for (var i = 0; i < data.length; i++) {
                        html += '<label for="' + 'line' + i + '" style="margin-left: 5px;"> &nbsp;';
                        html += '<input type="checkbox" name="line[]" id="' + 'line' + i + '" value="' + data[i]["WorkcellDesc"] + '" />' + ' ' + data[i]["WorkcellDesc"] + '</label>';
                    }
                    $('#checkboxes').append(html);
                }
                else {
                    html += '<label style="margin-left: 5px;"> No Machine Found</label>';
                    $('#checkboxes').append(html);
                }
            }
        });
    }
}

var btnClickCnt = 0

function ViewReport() {
    var Report = document.getElementById("ddlreport").value;
    btnClickCnt = 0
    if (Report == "Loss Summary Report") {
        document.getElementById("l1").innerHTML = Report;
        getShiftLossSummeryData();
    }
    else if (Report == "MMP Report") {
        document.getElementById("l1").innerHTML = Report;
        GetMMPreportData();
    }
    else if (Report == "No Touch Report") {
        document.getElementById("l1").innerHTML = Report;
        notouchdashboard();
    }
    else if (Report == "Production Report") {
        document.getElementById("l1").innerHTML = Report;
        getProductionDetailData();
    }
    else if (Report == "Loss Detail Report") {
        document.getElementById("l1").innerHTML = Report;
        getLossDetailData();
    }
}


function getShiftLossSummeryData() {
    debugger;
    $('#LossSummeryBody').empty();
    $('#tbllosssummery').dataTable().fnClearTable();
    $('#tbllosssummery').dataTable().fnDestroy();

    var FromDate = document.getElementById("date_from").value;
    var ToDate = document.getElementById("date_To").value;
    // var shift = document.getElementById("ddlshift").value;

    var linecheck = document.getElementsByName('line[]');
    var line = "";
    for (var i = 0, n = linecheck.length; i < n; i++) {

        if (linecheck[i].checked) {
            if (line == '') {
                line += "'" + linecheck[i].value + "'";
            } else {
                line += ",'" + linecheck[i].value + "'";
            }
        }
    }

    var shiftcheck = document.getElementsByName('shift[]');
    var shift = "";
    for (var i = 0, n = shiftcheck.length; i < n; i++) {

        if (shiftcheck[i].checked) {
            if (shift == '') {
                shift += "'" + shiftcheck[i].value + "'";
            } else {
                shift += ",'" + shiftcheck[i].value + "'";
            }
        }
    }

    $.ajax({
        type: 'GET',
        url: '/getAllSmrtTags',
        // data: { machine: machine },
        async: false,
        success: function (res) {
            debugger;
            $.ajax({
                type: 'GET',
                url: '/DemandShiftLossSummeryData',
                data: { FromDate: FromDate, ToDate: ToDate, line: line, shift: shift },
                async: false,
                success: function (data) {
                    debugger;
                    var cnt = 0;
                    if (data != "") {
                        var response = data.recordset;
                        if (response.length > 0) {
                            if (res != '') {
                                var smartTagResult = res.recordset;

                                var tDate = [...new Set(response.map(x => x.tDate))];
                                for (var e = 0; e < tDate.length; e++) {
                                    var dateData = response.filter(ro => String(ro.tDate).includes(tDate[e]));

                                    var DistinctShift = [...new Set(dateData.map(x => x.sShift))];
                                    DistinctShift.sort();
                                    for (var z = 0; z < DistinctShift.length; z++) {
                                        var shiftData = dateData.filter(dd => (String(dd.sShift) == (DistinctShift[z])));
                                        var distinctworkcell = [...new Set(shiftData.map(x => x.WorkcellDesc))];
                                        for (var f = 0; f < distinctworkcell.length; f++) {
                                            var workcellData = shiftData.filter(dd => (String(dd.WorkcellDesc) == (distinctworkcell[f])));
                                            var workcellSmartTAgs = smartTagResult.filter(dd => (String(dd.MachineName) == (distinctworkcell[f])));
                                            workcellSmartTAgs.sort(function (a, b) {
                                                return a.MMPCodeID - b.MMPCodeID && a.CategoryCode - b.CategoryCode;
                                            });

                                            var distinctMMPLossCodeDesc = [...new Set(workcellSmartTAgs.map(x => x.MMPLossCodeDesc))];
                                            for (var g = 0; g < distinctMMPLossCodeDesc.length; g++) {
                                                var mmplossdescArr = workcellSmartTAgs.filter(dd => (String(dd.MMPLossCodeDesc) == (distinctMMPLossCodeDesc[g])));
                                                var distinctsmart = [...new Set(mmplossdescArr.map(x => x.SmartTag))];

                                                for (var s = 0; s < distinctsmart.length; s++) {
                                                    var SmartTAgsVal = workcellData.filter(dd => (String(dd.LossDesc) == (distinctsmart[s]))
                                                        && (String(dd.MMPLossCodeDesc) == (distinctMMPLossCodeDesc[g])));
                                                    if (SmartTAgsVal.length > 0) {
                                                        var smartmin = 0;
                                                        for (var l = 0; l < SmartTAgsVal.length; l++) {
                                                            smartmin += SmartTAgsVal[l]["TotalSec"];
                                                        }
                                                        var row1 = '<tr>';
                                                        var st = tDate[e];
                                                        var st1 = st.split("T");
                                                        var dt = st1[0];
                                                        var sr = cnt + 1
                                                        row1 += '<td>' + sr + '</td>';
                                                        row1 += '<td>' + dt + '</td>';
                                                        row1 += '<td>' + DistinctShift[z] + '</td>';
                                                        row1 += '<td>' + distinctworkcell[f] + '</td>';
                                                        row1 += '<td>' + SmartTAgsVal[0]["MMPCodeDesc"] + '</td>';
                                                        row1 += '<td>' + SmartTAgsVal[0]["MMPLossCodeDesc"] + '</td>';
                                                        row1 += '<td>' + distinctsmart[s] + '</td>';
                                                        row1 += '<td>' + (smartmin / 60).toFixed(2) + '</td>';
                                                        row1 += '</tr>';
                                                        $('#tbllosssummery').append(row1);
                                                        cnt++;
                                                    }
                                                    else {
                                                        var row1 = '<tr>';
                                                        var st = tDate[e];
                                                        var st1 = st.split("T");
                                                        var dt = st1[0];
                                                        var sr = cnt + 1
                                                        row1 += '<td>' + sr + '</td>';
                                                        row1 += '<td>' + dt + '</td>';
                                                        row1 += '<td>' + DistinctShift[z] + '</td>';
                                                        row1 += '<td>' + distinctworkcell[f] + '</td>';
                                                        row1 += '<td>' + mmplossdescArr[0]["MMPCodeDesc"] + '</td>';
                                                        row1 += '<td>' + mmplossdescArr[0]["MMPLossCodeDesc"] + '</td>';
                                                        row1 += '<td>' + distinctsmart[s] + '</td>';
                                                        row1 += '<td>' + 0 + '</td>';
                                                        row1 += '</tr>';
                                                        $('#tbllosssummery').append(row1);
                                                        cnt++;
                                                    }

                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            });
        }
    });
    $('#tbllosssummery').DataTable({
        dom: 'Bfrtip',
        // paging: false,
        // searching: false,
        buttons: [
            $.extend(true, {}, buttonCommon, {
                extend: 'excelHtml5',
                text: 'Export To Excel',
                color: "blue",
                filename: function () {
                    var filename = new Date();
                    var dateFormat = "Y-m-d H-i";
                    filename = format(filename, dateFormat);
                    var name = "Loss Summery Report" + " " + filename;
                    return name
                }
            }),
        ]
    });
}


function GetMMPreportData() {
    $("#checkboxes").hide();
    $("#checkboxesShift").hide();
    $('#MMPtbody').empty();
    var FromDate = document.getElementById("date_from").value;
    var ToDate = document.getElementById("date_To").value;
    // var shift = document.getElementById("ddlshift").value;
    //var type = document.getElementById("ddltype").value;

    var linecheck = document.getElementsByName('line[]');
    var line = "";
    for (var i = 0, n = linecheck.length; i < n; i++) {

        if (linecheck[i].checked) {
            if (line == '') {
                line += "'" + linecheck[i].value + "'";
            } else {
                line += ",'" + linecheck[i].value + "'";
            }
        }
    }

    var shiftcheck = document.getElementsByName('shift[]');
    var shift = "";
    for (var i = 0, n = shiftcheck.length; i < n; i++) {

        if (shiftcheck[i].checked) {
            if (shift == '') {
                shift += "'" + shiftcheck[i].value + "'";
            } else {
                shift += ",'" + shiftcheck[i].value + "'";
            }
        }
    }

    // if (type == '-Select Machine type-') {
    //     alert('Please select machine type..');
    // }
   // else {
        $.ajax({
            type: 'GET',
            url: '/getAllLosses',
            data: {line },
            success: function (result) {
                var res = JSON.parse(JSON.stringify(result.recordset));
                if (res.length > 0) {
                    var row = '<tr id="Tr0">';
                    row += '<td style="background-color: rgb(9, 64, 111); border-width: 1px; padding: 8px; border-style: solid; border-color: black; color: white;">' + 'Description' + '</td>';
                    row += '<td style="background-color: rgb(9, 64, 111); border-width: 1px; padding: 8px; border-style: solid; border-color: black; color: white;">' + 'Units' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr1">';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Date' + '</td>';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Date' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr2">';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Shift' + '</td>';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Shift' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    if (type == 'Process') {
                        var row = '<tr id="Tr3">';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Design Speed' + '</td>';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Batches/Hr' + '</td>';
                        row += '</tr>';
                        $('#MMPtbody').append(row);

                        var row = '<tr id="Tr4">';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Volume Produced - Good Product' + '</td>';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Batch' + '</td>';
                        row += '</tr>';
                        $('#MMPtbody').append(row);

                        var row = '<tr id="Tr5">';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Volume Produced - Off Spec Product' + '</td>';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Batch' + '</td>';
                        row += '</tr>';
                        $('#MMPtbody').append(row);
                    }
                    else {
                        var row = '<tr id="Tr3">';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Design Speed' + '</td>';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Tab. / Min.' + '</td>';
                        row += '</tr>';
                        $('#MMPtbody').append(row);

                        var row = '<tr id="Tr4">';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Volume Produced - Good Product' + '</td>';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'CLD' + '</td>';
                        row += '</tr>';
                        $('#MMPtbody').append(row);

                        var row = '<tr id="Tr5">';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'Volume Produced - Off Spec Product' + '</td>';
                        row += '<td style="border-width: 1px; padding: 8px; border-style: solid; background-color: white; border-color: black;">' + 'CLD' + '</td>';
                        row += '</tr>';
                        $('#MMPtbody').append(row);
                    }

                    var row = '<tr id="Tr6">';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Total Time' + '</td>';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Mins.' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr7">';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'AVAILABLE TIME' + '</td>';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Mins.' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr8">';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'LOADING TIME' + '</td>';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Mins.' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr9">';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'OPERATING TIME' + '</td>';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Mins.' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var maincode = [...new Set(res.map(x => x.MMPCodeDesc))];
                    for (var f = 0; f < maincode.length; f++) {
                        var row = '<tr id="' + "Trmain" + f + '" class="TrMain">';
                        row += '<td style="background-color: #d3d3d373;border-width: 1px; padding: 8px; border-style: solid; border-color: black;text-align:center">' + maincode[f] + '</td>';
                        row += '<td style="background-color: #d3d3d373;border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + '' + '</td>';
                        row += '</tr>';
                        $('#MMPtbody').append(row);

                        var mainlossData = res.filter(dd => (String(dd.MMPCodeDesc) == (maincode[f])));
                        var subcode = [...new Set(mainlossData.map(x => x.MMPLossCodeDesc))];
                        for (i = 0; i < subcode.length; i++) {
                            var row = '<tr id="' + "Trsub" + i + f + '" class="TrSub">';
                            row += '<td style="background-color: lightgray;;border-width: 1px; padding: 8px; border-style: solid; border-color: black;text-align:center">' + subcode[i] + '</td>';
                            row += '<td style="background-color: lightgray;;border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + '' + '</td>';
                            row += '</tr>';
                            $('#MMPtbody').append(row);

                            var sublossData = mainlossData.filter(dd => (String(dd.MMPLossCodeDesc) == (subcode[i])));
                            var level2code = sublossData[0]["CategoryCode"];
                            var SmartTag = [...new Set(sublossData.map(x => x.SmartTag))];
                            for (var e = 0; e < SmartTag.length; e++) {
                                var smartid = SmartTag[e].trim();
                                var row = '<tr id="' + smartid + '_' + level2code + '" class="smartloss">';
                                row += '<td style="border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + SmartTag[e] + '</td>';
                                row += '<td style="border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                                row += '</tr>';
                                $('#MMPtbody').append(row);
                            }
                            var row = '<tr id="' + subcode[i].trim() + '" class="subloss">';
                            row += '<td style="background-color: rgb(191, 176, 249);border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Total ' + subcode[i] + '</td>';
                            row += '<td style="background-color: rgb(191, 176, 249);border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                            row += '</tr>';
                            $('#MMPtbody').append(row);
                        }
                        var row = '<tr id="' + maincode[f].trim() + '_' + f + '" class="mainloss">';
                        row += '<td style="background-color: rgb(174 77 234 / 42%);border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Total ' + maincode[f] + '</td>';
                        row += '<td style="background-color: rgb(174 77 234 / 42%);border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                        row += '</tr>';
                        $('#MMPtbody').append(row);
                    }

                    var row = '<tr id="Tr10">';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'VALUE OPERATING TIME' + '</td>';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Mins.' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr11">';
                    row += '<td style="background-color: rgb(9, 64, 111); border-width: 1px; padding: 8px; border-style: solid; border-color: black;color:white">' + 'CAPACITY UTILISATION, OEE INDEXES &amp; KPI' + '</td>';
                    row += '<td style="background-color: rgb(9, 64, 111); border-width: 1px; padding: 8px; border-style: solid; border-color: black;color:white">' + 'Units' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="OEE">';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'OEE' + '</td>';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + '%' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr12">';
                    row += '<td style="background-color: rgb(9, 64, 111); border-width: 1px; padding: 8px; border-style: solid; border-color: black;color:white">' + 'TIME ALLOCATION CROSS CHECK' + '</td>';
                    row += '<td style="background-color: rgb(9, 64, 111); border-width: 1px; padding: 8px; border-style: solid; border-color: black;color:white">' + 'Units' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr13">';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Calculated Value Operating Time' + '</td>';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr14">';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Calculated Unaccounted For Time' + '</td>';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr15">';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Calculated Unaccounted For Time' + '</td>';
                    row += '<td style="border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + '% LoadT' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr16">';
                    row += '<td style="background-color: rgb(9, 64, 111);border-width: 1px; padding: 8px; border-style: solid; border-color: black;color:white">' + 'OTHER LOSS TREE RELATED KPIS' + '</td>';
                    row += '<td style="background-color: rgb(9, 64, 111);border-width: 1px; padding: 8px; border-style: solid; border-color: black;color:white">' + 'Units' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr17">';
                    row += '<td style="background-color: lightyellow;border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Number Of Breakdowns' + '</td>';
                    row += '<td style="background-color: lightyellow;border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Quantity' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    var row = '<tr id="Tr18">';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Number Of Changovers' + '</td>';
                    row += '<td style="background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Quantity' + '</td>';
                    row += '</tr>';
                    $('#MMPtbody').append(row);

                    //#region nothing know data 

                    // var row = '<tr id="Tr20">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Format' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Quantity' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr21">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Product' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Quantity' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr22">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Decorations &amp; Others' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Quantity' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr23">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Changover Time' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr24">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Format' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr25">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Product' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr26">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Decorations &amp; Others' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Min.' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr27">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Average Changover Time for Format (ACOT-F)' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'H/Event' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr28">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Average Changover Time for Product (ACOT-P)' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'H/Event' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);

                    // var row = '<tr id="Tr29">';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'Average Changover Time for Decorations and Others(ACOT-D&O)' + '</td>';
                    // row += '<td background-color: lightyellow; border-width: 1px; padding: 8px; border-style: solid; border-color: black;">' + 'H/Event' + '</td>';
                    // row += '</tr>';
                    // $('#MMPtbody').append(row);
                    //#endregion
                }
                var response = [];
                $.ajax({
                    type: 'GET',
                    url: '/DemandMMPreportData',
                    data: { FromDate: FromDate, ToDate: ToDate, shift: shift, line: line },
                    async: false,
                    success: function (data) {
                        debugger;

                        if (data != "") {
                            response = data.recordset;
                            var coloumnCount = data.rowsAffected;
                            if (response.length > 0) {
                                var workcell = [...new Set(response.map(x => x.WorkcellDesc))];
                                workcell.sort();
                                for (var f = 0; f < workcell.length; f++) {

                                    var machineData = response.filter(dd => (String(dd.WorkcellDesc) == (workcell[f])));
                                    var DistinctDate = [...new Set(machineData.map(x => x.tDate))];
                                    for (var s = 0; s < DistinctDate.length; s++) {

                                        var dateData = machineData.filter(dd => (String(dd.tDate).includes(DistinctDate[s])));

                                        var DistinctShift = [...new Set(dateData.map(x => x.sShift))];
                                        DistinctShift.sort();
                                        for (var z = 0; z < DistinctShift.length; z++) {
                                            var row = document.getElementById("Tr0");
                                            var cell = row.insertCell(-1);
                                            cell.innerHTML = "<th style='border: 1px solid #262626 !important; padding: 8px;'>" + workcell[f] + "</th>";
                                            $(cell).css("border", "1px");
                                            $(cell).css("border-color", "#262626");
                                            $(cell).css("border-style", "solid");
                                            $(cell).css("padding", "8px");
                                            $(cell).css("background-color", "rgb(9, 64, 111)");
                                            $(cell).css("color", "#ffffff");

                                            var dt = DistinctDate[s].split('T');
                                            var row = document.getElementById("Tr1");
                                            var cell = row.insertCell(-1);
                                            cell.innerHTML = "<th style='border: 1px solid #262626 !important; padding: 8px;'>" + dt[0] + "</th>";
                                            $(cell).css("border", "1px");
                                            $(cell).css("border-color", "#262626");
                                            $(cell).css("border-style", "solid");
                                            $(cell).css("padding", "8px");
                                            $(cell).css("background-color", "lightyellow");

                                            var row = document.getElementById("Tr2");
                                            var cell = row.insertCell(-1);
                                            cell.innerHTML = "<th style='border: 1px solid #262626 !important; padding: 8px;'>" + DistinctShift[z] + "</th>";
                                            $(cell).css("border", "1px");
                                            $(cell).css("border-color", "#262626");
                                            $(cell).css("border-style", "solid");
                                            $(cell).css("padding", "8px");
                                            $(cell).css("background-color", "lightyellow");

                                            var shiftData = dateData.filter(dd => (String(dd.sShift).includes(DistinctShift[z])));
                                            for (var j = 0; j < shiftData.length; j++) {
                                                if (shiftData[j].WorkcellDesc == 'Process') {
                                                    var designspeed = shiftData[j].dDesignSpeedProcess;
                                                }
                                                else {
                                                    var designspeed = shiftData[j].dDesignSpeed;
                                                }
                                                var row = document.getElementById("Tr3");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + designspeed + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "rgb(162, 162, 162)");

                                                var row = document.getElementById("Tr4");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + shiftData[j].CLDCount + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "rgb(162, 162, 162)");

                                                var row = document.getElementById("Tr5");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>0</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "rgb(162, 162, 162)");

                                                var row = document.getElementById("Tr6");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + shiftData[j].dTotal + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "lightyellow");

                                                var row = document.getElementById("Tr7");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626; padding: 8px;'>" + shiftData[j].dAvailable + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "lightyellow");

                                                var LTime = shiftData[j].dLoadingTime;
                                                var row = document.getElementById("Tr8");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + LTime + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "lightyellow");

                                                var row = document.getElementById("Tr9");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + (shiftData[j].dOperatingTime).toFixed(2) + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "lightyellow");

                                                var VOT = shiftData[j].dValueOperatingTime;
                                                var row = document.getElementById("Tr10");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + (shiftData[j].dValueOperatingTime).toFixed(2) + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "lightyellow");

                                                var row = document.getElementById("Tr11");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + shiftData[j].WorkcellDesc + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "rgb(9, 64, 111)");
                                                $(cell).css("color", "white");

                                                if (shiftData[j].WorkcellDesc == 'Process') {
                                                    var oee = shiftData[j].dOEEProcess;
                                                    if (oee == null) {
                                                        oee = 0;
                                                    }
                                                    if (oee > 100) {
                                                        oee = 100;
                                                    }
                                                }
                                                else {
                                                    var oee = shiftData[j].dOEE;
                                                    if (oee == null) {
                                                        oee = 0;
                                                    }
                                                    if (oee > 100) {
                                                        oee = 100;
                                                    }
                                                }
                                                var row = document.getElementById("OEE");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + (oee).toFixed(2) + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "lightyellow");

                                                var row = document.getElementById("Tr12");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + shiftData[j].WorkcellDesc + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "rgb(9, 64, 111)");
                                                $(cell).css("color", "white");

                                                if (shiftData[j].WorkcellDesc == 'Process') {
                                                    var CVOTprocess = shiftData[j].dCalculatedVOTProcess;
                                                    if (CVOTprocess == null) {
                                                        CVOTprocess = 0;
                                                    }
                                                    var row = document.getElementById("Tr13");
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + (CVOTprocess).toFixed(2) + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");

                                                    //#region  VOT
                                                    var UnAccTime = Math.abs(CVOTprocess - VOT);
                                                    if (UnAccTime > 0) {
                                                        var row = document.getElementById("Tr14");
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + UnAccTime.toFixed(2) + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                    }
                                                    else {
                                                        var row = document.getElementById("Tr14");
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + 0 + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                    }
                                                    if (LTime > 0) {
                                                        var UnAccTimePer = parseFloat((UnAccTime / LTime) * 100);

                                                        var row = document.getElementById("Tr15");
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + UnAccTimePer.toFixed(2) + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                    }
                                                    else {
                                                        var row = document.getElementById("Tr15");
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + 0 + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                    }
                                                    //#endregion

                                                }
                                                else {
                                                    var row = document.getElementById("Tr13");
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + (shiftData[j].dCalculatedVOT).toFixed(2) + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");

                                                    var row = document.getElementById("Tr14");
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + Math.abs(shiftData[j].dUnaccountedTime).toFixed(2) + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");

                                                    var row = document.getElementById("Tr15");
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + Math.abs(shiftData[j].dUnaccountedPercent).toFixed(2) + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                }


                                                var row = document.getElementById("Tr16");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + shiftData[j].WorkcellDesc + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "rgb(9, 64, 111)");
                                                $(cell).css("color", "white");

                                                var row = document.getElementById("Tr17");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + shiftData[j].MMPLossCode13Count + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "rgb(162, 162, 162)");

                                                var row = document.getElementById("Tr18");
                                                var cell = row.insertCell(-1);
                                                cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + shiftData[j].MMPLossCode11Count + "</td>";
                                                $(cell).css("border", "1px");
                                                $(cell).css("border-color", "#262626");
                                                $(cell).css("border-style", "solid");
                                                $(cell).css("padding", "8px");
                                                $(cell).css("background-color", "lightyellow");
                                            }
                                        }
                                    }
                                }

                            }

                            if (coloumnCount > 0) {
                                $("#MMPDiv").css("display", "block");
                            }
                        }
                    },
                    failure: function (response) {
                        alert(arr);
                    }
                });

                $.ajax({
                    type: 'GET',
                    url: '/DemandAllLossesData',
                    data: { FromDate: FromDate, ToDate: ToDate, shift: shift, line: line },
                    success: function (res) {
                        if (res != '') {
                            var result = res.recordset;
                            if (result.length > 0) {
                                var shiftData = [];
                                var workcell = [...new Set(response.map(x => x.WorkcellDesc))];
                                for (var f = 0; f < workcell.length; f++) {
                                    var machineData = response.filter(dd => (String(dd.WorkcellDesc) == (workcell[f])));
                                    var DistinctDate = [...new Set(machineData.map(x => x.tDate))];
                                    for (var s = 0; s < DistinctDate.length; s++) {

                                        var dateData = machineData.filter(dd => (String(dd.tDate).includes(DistinctDate[s])));

                                        var DistinctShift = [...new Set(dateData.map(x => x.sShift))];
                                        DistinctShift.sort();
                                        for (var z = 0; z < DistinctShift.length; z++) {
                                            shiftData = result.filter(dd => (String(dd.WorkcellDesc) == (workcell[f])) &&
                                                (String(dd.sShift) == (DistinctShift[z])) && (String(dd.tDate) == (DistinctDate[s])));

                                            if (shiftData.length > 0) {

                                               
                                            //#region smart losses
                                            var row1 = document.getElementsByClassName("smartloss");
                                            for (var q = 0; q < row1.length; q++) {
                                                var rowid = (row1[q].id).split('_');
                                                var val = shiftData.filter(dd => (String((dd.LossDesc).toLowerCase().trim()) == (rowid[0]).toLowerCase().trim())
                                                    && (String(dd.MMPLossCodeID) == (rowid[1])));
                                                if ((rowid[0]).toLowerCase().trim() == 'speed loss') {
                                                    var forspeedmin=0;
                                                    if (workcell[f] != 'Process') {
                                                        var packingData = response.filter(dd => (String(dd.WorkcellDesc) == (workcell[f]))
                                                        && (String(dd.sShift) == DistinctShift[z]));
                                                        forspeedmin = packingData[0]["SpeedLoss"].toFixed(2);
                                                    }
                                                    else {
                                                        var speedLossMin = 0;
                                                        var valspeedloss = shiftData.filter(dd => (String((dd.LossDesc).toLowerCase().trim()) != 'speed loss')
                                                            && (String(dd.MMPLossCodeID) == 45));
                                                        for (var l = 0; l < valspeedloss.length; l++) {
                                                            var speedmin = parseFloat((valspeedloss[l]["TotalSec"]) / 60);
                                                            speedLossMin += speedmin;
                                                        }

                                                        forspeedmin = parseFloat(smartMin - speedLossMin).toFixed(2);
                                                        // if (forspeedmin <= 0) {
                                                        //     forspeedmin = 0;
                                                        // }
                                                    }
                                                    var row = document.getElementById(row1[q].id);
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" +forspeedmin + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                    $(cell).css("background-color", "rgb(162, 162, 162)");
                                                } 
                                                else if (val.length > 0) {
                                                        var smartMin = 0;
                                                        for (var f1 = 0; f1 < val.length; f1++) {
                                                            var min = parseFloat((val[f1]["TotalSec"]) / 60);
                                                            smartMin += min;
                                                        }

                                                        var row = document.getElementById(row1[q].id);
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + smartMin.toFixed(2) + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                        $(cell).css("background-color", "rgb(162, 162, 162)");

                                                    }
                                                    else {
                                                        var row = document.getElementById(row1[q].id);
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + 0 + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                        $(cell).css("background-color", "rgb(162, 162, 162)");
                                                    }
                                            }
                                            //#endregion


                                            var rowsub = document.getElementsByClassName("subloss");
                                            for (var q1 = 0; q1 < rowsub.length; q1++) {
                                                var rowsubid = rowsub[q1].id;
                                                var subdescData = shiftData.filter(dd => (String((dd.MMPLossCodeDesc)) == (rowsubid)));
                                                var totalmin = 0;

                                                if (rowsubid == 'Speed Loss') {
                                                    var speedLossSubMin = 0;
                                                    var withoutspeedloss = shiftData.filter(dd => (String((dd.LossDesc).toLowerCase().trim()) != 'speed loss')
                                                        && (String(dd.MMPLossCodeID) == 45));
                                                    for (var l1 = 0; l1 < withoutspeedloss.length; l1++) {
                                                        var speedmin = parseFloat((withoutspeedloss[l1]["TotalSec"]) / 60);
                                                        speedLossSubMin += speedmin;
                                                    }
                                                    var withtotalspeedloss = 0;
                                                    if (workcell[f] != 'Process') {
                                                        var packingData = response.filter(dd => (String(dd.WorkcellDesc) == (workcell[f]))
                                                        && (String(dd.sShift) == DistinctShift[z]));
                                                        var speedmin = packingData[0]["SpeedLoss"];
                                                        totalmin = speedLossSubMin + speedmin;
                                                    }
                                                    else {
                                                        var withspeedloss = shiftData.filter(dd => (String((dd.LossDesc).toLowerCase().trim()) == 'speed loss'));
                                                        for (var l2 = 0; l2 < withspeedloss.length; l2++) {
                                                            var speedwithmin = parseFloat((withspeedloss[l2]["TotalSec"]) / 60);
                                                            withtotalspeedloss += speedwithmin;
                                                        }

                                                        var Subspeedlossmin = parseFloat(withtotalspeedloss - speedLossSubMin);
                                                        if (Subspeedlossmin <= 0) {
                                                            Subspeedlossmin = 0;
                                                        }

                                                        totalmin = speedLossSubMin + Subspeedlossmin;
                                                    }
                                                    var row = document.getElementById(rowsubid);
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + totalmin.toFixed(2) + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                    $(cell).css("background-color", "rgb(191, 176, 249)");
                                                }
                                                else if (subdescData.length > 0) {

                                                    for (var t = 0; t < subdescData.length; t++) {
                                                        var tmin = parseFloat((subdescData[t]["TotalSec"]) / 60);
                                                        totalmin += tmin;
                                                    }
                                                    var row = document.getElementById(rowsubid);
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + totalmin.toFixed(2) + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                    $(cell).css("background-color", "rgb(191, 176, 249)");
                                                }
                                                else {
                                                    var row = document.getElementById(rowsubid);
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '0' + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                    $(cell).css("background-color", "rgb(191, 176, 249)");
                                                }
                                            }


                                            var rowmain = document.getElementsByClassName("mainloss");
                                            for (var d = 0; d < rowmain.length; d++) {
                                                var rowmainid = (rowmain[d].id).split('_');
                                                var mainval = shiftData.filter(dd => (String((dd.MMPCodeDesc)).includes(rowmainid[0])));
                                                if (mainval.length > 0) {
                                                    var totalMainLossMin = 0;
                                                    if (mainval[0]["MMPCodeID"] == 4) {
                                                        var speedLossSubMin = 0;
                                                        var withoutspeedloss = shiftData.filter(dd => (String((dd.LossDesc).toLowerCase().trim()) != 'speed loss')
                                                            && (String(dd.MMPLossCodeID) == 45));
                                                        for (var l1 = 0; l1 < withoutspeedloss.length; l1++) {
                                                            var speedmin = parseFloat((withoutspeedloss[l1]["TotalSec"]) / 60);
                                                            speedLossSubMin += speedmin;
                                                        }

                                                        var withtotalspeedloss = 0;
                                                        if (workcell[f] != 'Process') {
                                                            var packingData = response.filter(dd => (String(dd.WorkcellDesc) == (workcell[f]))
                                                            && (String(dd.sShift) == DistinctShift[z]));
                                                            var speedmin = packingData[0]["SpeedLoss"];
                                                            var totalspeedmin = speedLossSubMin + speedmin;
                                                        }
                                                        else {
                                                            var withspeedloss = shiftData.filter(dd => (String((dd.LossDesc).toLowerCase().trim()) == 'speed loss'));
                                                            for (var l2 = 0; l2 < withspeedloss.length; l2++) {
                                                                var speedwithmin = parseFloat((withspeedloss[l2]["TotalSec"]) / 60);
                                                                withtotalspeedloss += speedwithmin;
                                                            }

                                                            var Subspeedlossmin = parseFloat(withtotalspeedloss - speedLossSubMin);
                                                            if (Subspeedlossmin <= 0) {
                                                                Subspeedlossmin = 0;
                                                            }

                                                            var totalspeedmin = speedLossSubMin + Subspeedlossmin;

                                                        }
                                                        var withoutspeedloss = shiftData.filter(dd => (String(dd.MMPLossCodeID) != 45 &&
                                                            (String(dd.MMPLossCodeID) != 19))
                                                            && (String(dd.MMPCodeID) == 4));
                                                        var mm = 0;
                                                        for (var t1 = 0; t1 < withoutspeedloss.length; t1++) {
                                                            var wsmin = parseFloat((withoutspeedloss[t1]["TotalSec"]) / 60);
                                                            mm += wsmin;
                                                        }

                                                        totalMainLossMin = totalspeedmin + mm;
                                                    }
                                                    else {
                                                        for (var t = 0; t < mainval.length; t++) {
                                                            var tmin = parseFloat((mainval[t]["TotalSec"]) / 60);
                                                            totalMainLossMin += tmin;
                                                        }
                                                    }
                                                    var row = document.getElementById(rowmain[d].id);
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + totalMainLossMin.toFixed(2) + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                    $(cell).css("background-color", "rgb(174 77 234 / 42%)");
                                                }
                                                else {
                                                    var row = document.getElementById(rowmain[d].id);
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '0' + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                    $(cell).css("background-color", "rgb(174 77 234 / 42%)");
                                                }
                                            }



                                                var row1 = document.getElementsByClassName("TrMain");
                                                for (var q = 0; q < row1.length; q++) {
                                                    var rowid = row1[q].id;
                                                    var row = document.getElementById(rowid);
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '' + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                    $(cell).css("background-color", "#d3d3d373");
                                                }

                                                var row2 = document.getElementsByClassName("TrSub");
                                                for (var q = 0; q < row2.length; q++) {
                                                    var rowid = row2[q].id;
                                                    var row = document.getElementById(rowid);
                                                    var cell = row.insertCell(-1);
                                                    cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '' + "</td>";
                                                    $(cell).css("border", "1px");
                                                    $(cell).css("border-color", "#262626");
                                                    $(cell).css("border-style", "solid");
                                                    $(cell).css("padding", "8px");
                                                    $(cell).css("background-color", "lightgray");
                                                }
                                            }
                                            else {
                                                if (response.length > 0) {
                                                    //#region smart losses
                                                    var row1 = document.getElementsByClassName("smartloss");
                                                    for (var q = 0; q < row1.length; q++) {
                                                        var row = document.getElementById(row1[q].id);
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + 0 + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                        $(cell).css("background-color", "rgb(162, 162, 162)");
                                                    }
                                                    //#endregion

                                                    var rowsub = document.getElementsByClassName("subloss");
                                                    for (var q1 = 0; q1 < rowsub.length; q1++) {
                                                        var rowsubid = rowsub[q1].id;
                                                        var row = document.getElementById(rowsubid);
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '0' + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                        $(cell).css("background-color", "rgb(191, 176, 249)");
                                                    }

                                                    var rowmain = document.getElementsByClassName("mainloss");
                                                    for (var d = 0; d < rowmain.length; d++) {
                                                        var row = document.getElementById(rowmain[d].id);
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '0' + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                        $(cell).css("background-color", "rgb(174 77 234 / 42%)");
                                                    }

                                                    var row1 = document.getElementsByClassName("TrMain");
                                                    for (var q = 0; q < row1.length; q++) {
                                                        var rowid = row1[q].id;

                                                        var row = document.getElementById(rowid);
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '' + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                        $(cell).css("background-color", "#d3d3d373");
                                                    }

                                                    var row2 = document.getElementsByClassName("TrSub");
                                                    for (var q = 0; q < row2.length; q++) {
                                                        var rowid = row2[q].id;
                                                        var row = document.getElementById(rowid);
                                                        var cell = row.insertCell(-1);
                                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '' + "</td>";
                                                        $(cell).css("border", "1px");
                                                        $(cell).css("border-color", "#262626");
                                                        $(cell).css("border-style", "solid");
                                                        $(cell).css("padding", "8px");
                                                        $(cell).css("background-color", "lightgray");
                                                    }                                    
                                                }
                                            }
                                        }
                                    }

                                }
                            }
                            else {
                                if (response.length > 0) {
                                    for (var t = 0; t < response.length; t++) {
                                        //#region smart losses
                                        var row1 = document.getElementsByClassName("smartloss");
                                        for (var q = 0; q < row1.length; q++) {
                                            var row = document.getElementById(row1[q].id);
                                            var cell = row.insertCell(-1);
                                            cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + 0 + "</td>";
                                            $(cell).css("border", "1px");
                                            $(cell).css("border-color", "#262626");
                                            $(cell).css("border-style", "solid");
                                            $(cell).css("padding", "8px");
                                            $(cell).css("background-color", "rgb(162, 162, 162)");
                                        }
                                        //#endregion

                                        var rowsub = document.getElementsByClassName("subloss");
                                        for (var q1 = 0; q1 < rowsub.length; q1++) {
                                            var rowsubid = rowsub[q1].id;
                                            var row = document.getElementById(rowsubid);
                                            var cell = row.insertCell(-1);
                                            cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '0' + "</td>";
                                            $(cell).css("border", "1px");
                                            $(cell).css("border-color", "#262626");
                                            $(cell).css("border-style", "solid");
                                            $(cell).css("padding", "8px");
                                            $(cell).css("background-color", "rgb(191, 176, 249)");
                                        }

                                        var rowmain = document.getElementsByClassName("mainloss");
                                        for (var d = 0; d < rowmain.length; d++) {
                                            var row = document.getElementById(rowmain[d].id);
                                            var cell = row.insertCell(-1);
                                            cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '0' + "</td>";
                                            $(cell).css("border", "1px");
                                            $(cell).css("border-color", "#262626");
                                            $(cell).css("border-style", "solid");
                                            $(cell).css("padding", "8px");
                                            $(cell).css("background-color", "rgb(174 77 234 / 42%)");
                                        }

                                        var row1 = document.getElementsByClassName("TrMain");
                                        for (var q = 0; q < row1.length; q++) {
                                            var rowid = row1[q].id;

                                            var row = document.getElementById(rowid);
                                            var cell = row.insertCell(-1);
                                            cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '' + "</td>";
                                            $(cell).css("border", "1px");
                                            $(cell).css("border-color", "#262626");
                                            $(cell).css("border-style", "solid");
                                            $(cell).css("padding", "8px");
                                            $(cell).css("background-color", "#d3d3d373");
                                        }

                                        var row2 = document.getElementsByClassName("TrSub");
                                        for (var q = 0; q < row2.length; q++) {
                                            var rowid = row2[q].id;
                                            var row = document.getElementById(rowid);
                                            var cell = row.insertCell(-1);
                                            cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '' + "</td>";
                                            $(cell).css("border", "1px");
                                            $(cell).css("border-color", "#262626");
                                            $(cell).css("border-style", "solid");
                                            $(cell).css("padding", "8px");
                                            $(cell).css("background-color", "lightgray");
                                        }                                    
                                    }
                                }
                            }
                        }
                        else {
                            if (response.length > 0) {
                                for (var t = 0; t < response.length; t++) {
                                    //#region smart losses
                                    var row1 = document.getElementsByClassName("smartloss");
                                    for (var q = 0; q < row1.length; q++) {
                                        var row = document.getElementById(row1[q].id);
                                        var cell = row.insertCell(-1);
                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + 0 + "</td>";
                                        $(cell).css("border", "1px");
                                        $(cell).css("border-color", "#262626");
                                        $(cell).css("border-style", "solid");
                                        $(cell).css("padding", "8px");
                                        $(cell).css("background-color", "rgb(162, 162, 162)");
                                    }
                                    //#endregion

                                    var rowsub = document.getElementsByClassName("subloss");
                                    for (var q1 = 0; q1 < rowsub.length; q1++) {
                                        var rowsubid = rowsub[q1].id;
                                        var row = document.getElementById(rowsubid);
                                        var cell = row.insertCell(-1);
                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '0' + "</td>";
                                        $(cell).css("border", "1px");
                                        $(cell).css("border-color", "#262626");
                                        $(cell).css("border-style", "solid");
                                        $(cell).css("padding", "8px");
                                        $(cell).css("background-color", "rgb(191, 176, 249)");
                                    }

                                    var rowmain = document.getElementsByClassName("mainloss");
                                    for (var d = 0; d < rowmain.length; d++) {
                                        var row = document.getElementById(rowmain[d].id);
                                        var cell = row.insertCell(-1);
                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '0' + "</td>";
                                        $(cell).css("border", "1px");
                                        $(cell).css("border-color", "#262626");
                                        $(cell).css("border-style", "solid");
                                        $(cell).css("padding", "8px");
                                        $(cell).css("background-color", "rgb(174 77 234 / 42%)");
                                    }

                                    var row1 = document.getElementsByClassName("TrMain");
                                    for (var q = 0; q < row1.length; q++) {
                                        var rowid = row1[q].id;

                                        var row = document.getElementById(rowid);
                                        var cell = row.insertCell(-1);
                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '' + "</td>";
                                        $(cell).css("border", "1px");
                                        $(cell).css("border-color", "#262626");
                                        $(cell).css("border-style", "solid");
                                        $(cell).css("padding", "8px");
                                        $(cell).css("background-color", "#d3d3d373");
                                    }

                                    var row2 = document.getElementsByClassName("TrSub");
                                    for (var q = 0; q < row2.length; q++) {
                                        var rowid = row2[q].id;
                                        var row = document.getElementById(rowid);
                                        var cell = row.insertCell(-1);
                                        cell.innerHTML = "<td style='border: 1px solid #262626 !important; padding: 8px;'>" + '' + "</td>";
                                        $(cell).css("border", "1px");
                                        $(cell).css("border-color", "#262626");
                                        $(cell).css("border-style", "solid");
                                        $(cell).css("padding", "8px");
                                        $(cell).css("background-color", "lightgray");
                                    }                                  
                                }
                            }
                        }
                    }
                })
            }
        })
  //  }
}


function getProductionDetailData() {
    debugger;
    $('#ProductionDetailBody').empty();
    $('#tblProductionDetail').dataTable().fnClearTable();
    $('#tblProductionDetail').dataTable().fnDestroy();

    var FromDate = document.getElementById("date_from").value;
    var ToDate = document.getElementById("date_To").value;
    // var shift = document.getElementById("ddlshift").value;

    var shiftcheck = document.getElementsByName('shift[]');
    var shift = "";
    for (var i = 0, n = shiftcheck.length; i < n; i++) {

        if (shiftcheck[i].checked) {
            if (shift == '') {
                shift += "'" + shiftcheck[i].value + "'";
            } else {
                shift += ",'" + shiftcheck[i].value + "'";
            }
        }
    }

    var linecheck = document.getElementsByName('line[]');
    var line = "";
    for (var i = 0, n = linecheck.length; i < n; i++) {

        if (linecheck[i].checked) {
            if (line == '') {
                line += "'" + linecheck[i].value + "'";
            } else {
                line += ",'" + linecheck[i].value + "'";
            }
        }
    }

    $.ajax({
        type: 'GET',
        url: '/DemandProductionDetailData',
        data: { FromDate: FromDate, ToDate: ToDate, line: line, shift: shift },
        async: false,
        success: function (data) {
            debugger;
            if (data != "") {
                var response = data.recordset;
                if (response.length > 0) {
                    $.each(response, function (i, d) {
                        var tDate = d["tDate"];
                        var Date = tDate.split("T");
                        var date = Date[0];

                        var row = '<tr>';
                        row += '<td>' + date + '</td>';
                        row += '<td>' + d["sShift"] + '</td>';
                        row += '<td>' + d["WorkcellDesc"] + '</td>';
                        row += '<td>' + d["dDesignSpeed"] + '</td>';
                        row += '<td>' + d["sPartId"] + '</td>';
                        row += '<td>' + d["CLDCount"] + '</td>';
                        row += '</tr>';
                        $('#tblProductionDetail').append(row);
                    });


                }
            }
        }
    });


    $('#tblProductionDetail').DataTable({
        dom: 'Bfrtip',
        // paging: false,
        // searching: false,
        buttons: [
            $.extend(true, {}, buttonCommon, {
                extend: 'excelHtml5',
                text: 'Export To Excel',
                color: "blue",
                filename: function () {
                    var filename = new Date();
                    var dateFormat = "Y-m-d H-i";
                    filename = format(filename, dateFormat);
                    var name = "Production Report" + " " + filename;
                    return name
                }
            }),
        ]
    });
}


function getLossDetailData() {
    debugger;
    $('#tblEventUpdate').dataTable().fnClearTable();
    $('#tblEventUpdate').dataTable().fnDestroy();
    $('#LossDetailBody').empty();
    var FromDate = document.getElementById("date_from").value;
    var ToDate = document.getElementById("date_To").value;
    // var shift = document.getElementById("ddlshift").value;

    var shiftcheck = document.getElementsByName('shift[]');
    var shift = "";
    for (var i = 0, n = shiftcheck.length; i < n; i++) {

        if (shiftcheck[i].checked) {
            if (shift == '') {
                shift += "'" + shiftcheck[i].value + "'";
            } else {
                shift += ",'" + shiftcheck[i].value + "'";
            }
        }
    }

    var linecheck = document.getElementsByName('line[]');
    var line = "";
    for (var i = 0, n = linecheck.length; i < n; i++) {

        if (linecheck[i].checked) {
            if (line == '') {
                line += "'" + linecheck[i].value + "'";
            } else {
                line += ",'" + linecheck[i].value + "'";
            }
        }
    }

    $.ajax({
        type: 'GET',
        url: '/DemandLossDetailData',
        data: { FromDate: FromDate, ToDate: ToDate, line: line, shift: shift },
        async: false,
        success: function (data) {
            debugger;
            if (data != "") {
                var response = data.recordset;
                if (response.length > 0) {
                    $.each(response, function (i, d) {
                        var st = d["tStart"];
                        var st1 = st.split("T");
                        var dt = st1[0];
                        var dt1 = st1[1].split(".");
                        var Sdt = dt1[0].split(":");
                        var St = Sdt[0];
                        var st1 = Sdt[1];
                        var startdt = dt + ":" + dt1[0];

                        var endtime = d["tEnd"];
                        var To1 = endtime.split("T");
                        var t = To1[0];
                        var t1 = To1[1].split(".");

                        var EndTm = t + ":" + t1[0];
                        const time = moment.utc(d["lSeconds"] * 1000).format('HH:mm:ss');

                        var row = '<tr>';
                        row += '<td>' + startdt + '</td>';
                        row += '<td>' + EndTm + '</td>';
                        row += '<td>' + time + '</td>';
                        row += '<td>' + d["LossDesc"] + '</td>';
                        row += '</tr>';
                        $('#tblEventUpdate').append(row);

                    });
                }
            }
        }
    });
    $('#tblEventUpdate').DataTable({
        dom: 'Bfrtip',
        buttons: [
            $.extend(true, {}, buttonCommon, {
                extend: 'excelHtml5',
                text: 'Export To Excel',
                color: "blue",
                filename: function () {
                    var filename = new Date();
                    var dateFormat = "Y-m-d H-i";
                    filename = format(filename, dateFormat);
                    var name = "Loss Detail Report" + " " + filename;
                    return name
                }
            }),
        ]
    });
}

function notouchdashboard() {
    debugger;
    $('#tblnotouchreport').dataTable().fnClearTable();
    $('#tblnotouchreport').dataTable().fnDestroy();
    $('#notouchreportBody').empty();
    var FromDate = document.getElementById("date_from").value;
    var ToDate = document.getElementById("date_To").value;
    // var shift = document.getElementById("ddlshift").value;

    var shiftcheck = document.getElementsByName('shift[]');
    var shift = "";
    for (var i = 0, n = shiftcheck.length; i < n; i++) {

        if (shiftcheck[i].checked) {
            if (shift == '') {
                shift += "'" + shiftcheck[i].value + "'";
            } else {
                shift += ",'" + shiftcheck[i].value + "'";
            }
        }
    }

    var linecheck = document.getElementsByName('line[]');
    var line = "";
    for (var i = 0, n = linecheck.length; i < n; i++) {

        if (linecheck[i].checked) {
            if (line == '') {
                line += "'" + linecheck[i].value + "'";
            } else {
                line += ",'" + linecheck[i].value + "'";
            }
        }
    }

    $.ajax({
        type: 'GET',
        url: '/Demandnotouch',
        data: { FromDate: FromDate, ToDate: ToDate, line: line, shift: shift },
        async: false,
        success: function (data) {
            debugger;
            if (data != "") {
                var response = JSON.parse(JSON.stringify(data.recordset));
                if (response.length > 0) {

                    $.each(response, function (i, d) {
                        var date = d["tDate"].split('T');

                        var row = '<tr>';
                        row += '<td>' + date[0] + '</td>';
                        row += '<td>' + d["sShift"] + '</td>';
                        row += '<td>' + d["WorkcellDesc"] + '</td>';
                        row += '<td>' + d["minlSeconds"].toFixed(2) + '</td>';
                        row += '<td>' + d["maxlSeconds"].toFixed(2) + '</td>';
                        row += '<td>' + d["avglSeconds"].toFixed(2) + '</td>';
                        row += '<td>' + d["count"] + '</td>';
                        row += '</tr>';
                        $('#notouchreportBody').append(row);
                    });
                }
            }
        }
    });

    $('#tblnotouchreport').DataTable({
        dom: 'Bfrtip',
        buttons: [
            $.extend(true, {}, buttonCommon, {
                extend: 'excelHtml5',
                text: 'Export To Excel',
                color: "blue",
                filename: function () {
                    var filename = new Date();
                    var dateFormat = "Y-m-d H-i";
                    filename = format(filename, dateFormat);
                    var name = "NoTouch Report" + " " + filename;
                    return name
                }
            }),
        ]
    });
}


function ShowLossDesc(rowIndexOfGridview) {
    debugger;
    $("#Losstbody").empty();
    var FromDate = document.getElementById("date_from").value;
    var ToDate = document.getElementById("date_To").value;

    var linecheck = document.getElementsByName('line[]');
    var line = "";
    for (var i = 0, n = linecheck.length; i < n; i++) {

        if (linecheck[i].checked) {
            if (line == '') {
                line += "'" + linecheck[i].value + "'";
            } else {
                line += ",'" + linecheck[i].value + "'";
            }
        }
    }

    var row = rowIndexOfGridview.parentNode.parentNode;
    var rowIndex = row.rowIndex - 1;

    var st = row.cells[1].outerText;
    var tstart = FromDate + " " + st;
    var et = row.cells[2].outerText;
    var tEnd = FromDate + " " + et;

    document.getElementById("lbldate").innerHTML = tstart;

    $.ajax({
        type: 'GET',
        url: '/Demandlossdesc',
        data: { FromDate: FromDate, ToDate: ToDate, line: line, tstart: tstart, tEnd: tEnd },
        async: false,
        success: function (data) {
            debugger;
            if (data != null) {
                var response = data.recordset;
                if (response.length > 0) {
                    $.each(response, function (i, d) {
                        var k = i + 1;
                        var Duration = d["lSeconds"];
                        var LossDesc = d["sEventDesc"];
                        Duration = Duration / 60.0;

                        Duration = Duration.toFixed(2);

                        var row = '<tr>';
                        row += '<td>' + k + '</td>';
                        row += '<td>' + LossDesc + '</td>';
                        row += '<td>' + Duration + '</td>';

                        row += '</tr>';
                        $('#Losstbody').append(row);
                    });
                }
            }

        }
    });

    $("#LossModal").modal('show');

}




var tableToExcelMMP = (function () {
    var uri = 'data:application/vnd.ms-excel;base64,',
        template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>',
        base64 = function (s) {
            return window.btoa(unescape(encodeURIComponent(s)))
        },
        format = function (s, c) {
            return s.replace(/{(\w+)}/g, function (m, p) {
                return c[p];
            })
        }
    return function (table, name) {
        name = "MMP Report";

        if (!table.nodeType) table = document.getElementById(table)
        var ctx = {
            worksheet: name || 'Worksheet',
            table: table.innerHTML

        }
        var selectDate = document.getElementById("date_from").value;

        var filename = "MMP Report" + " " + selectDate;
        // window.location.href = uri + base64(format(template, ctx))
        var link = document.createElement("a");
        link.download = filename;
        link.href = uri + base64(format(template, ctx));
        link.click();
    }
})()

var tableToExcelLossLive = (function () {
    var uri = 'data:application/vnd.ms-excel;base64,',
        template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>',
        base64 = function (s) {
            return window.btoa(unescape(encodeURIComponent(s)))
        },
        format = function (s, c) {
            return s.replace(/{(\w+)}/g, function (m, p) {
                return c[p];
            })
        }
    return function (table, name) {

        name = "Loss Live Report";

        if (!table.nodeType) table = document.getElementById(table)
        var ctx = {
            worksheet: name || 'Worksheet',
            table: table.innerHTML

        }
        var selectDate = document.getElementById("date_from").value;

        var filename = "Loss Live" + " " + selectDate;
        // window.location.href = uri + base64(format(template, ctx))
        var link = document.createElement("a");
        link.download = filename;
        link.href = uri + base64(format(template, ctx));
        link.click();
    }
})()

var tableToExcelNoTouch = (function () {
    var uri = 'data:application/vnd.ms-excel;base64,',
        template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--><meta http-equiv="content-type" content="text/plain; charset=UTF-8"/></head><body><table>{table}</table></body></html>',
        base64 = function (s) {
            return window.btoa(unescape(encodeURIComponent(s)))
        },
        format = function (s, c) {
            return s.replace(/{(\w+)}/g, function (m, p) {
                return c[p];
            })
        }
    return function (table, name) {

        name = "No Touch Report";

        if (!table.nodeType) table = document.getElementById(table)
        var ctx = {
            worksheet: name || 'Worksheet',
            table: table.innerHTML

        }
        var selectDate = document.getElementById("date_from").value;

        var filename = "NoTouch Report" + " " + selectDate;
        // window.location.href = uri + base64(format(template, ctx))
        var link = document.createElement("a");
        link.download = filename;
        link.href = uri + base64(format(template, ctx));
        link.click();
    }
})()
